from flask import Flask, render_template, send_file
import io
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

# Function to scrape and process data
def get_exchange_rate_data():
    url = "https://www.exchange-rates.org/exchange-rate-history/usd-idr"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    table = soup.select_one('body > div.layout.locale_en-US > div.content.container > div > div > section.box.history-rates-table-box > div > table')
    headers = [header.text.strip() for header in table.find_all('th')]
    rows = table.find_all('tr')
    data = []
    for row in rows[1:]: 
        cells = row.find_all('td')
        if len(cells) > 1:  
            date = cells[0].text.strip()
            rate = cells[1].text.strip()
            data.append([date, rate])
    df = pd.DataFrame(data, columns=headers)
    df['Date'] = df['Date'].apply(lambda x: x.split('\n')[0])
    df['Date'] = pd.to_datetime(df['Date'])
    df['Value'] = df['US Dollar to Indonesian Rupiah'].apply(lambda x: x.split(' ')[3].replace(',', ''))
    df['Value'] = pd.to_numeric(df['Value'])
    df = df[['Date', 'Value']]
    df = df.sort_values(by='Date', ascending=True).reset_index(drop=True)
    return df

# Route for the homepage
@app.route('/')
def home():
    return render_template('index.html')

# Route for displaying the plot
@app.route('/plot.png')
def plot_png():
    df = get_exchange_rate_data()
    plt.figure(figsize=(10, 6))
    sns.lineplot(x='Date', y='Value', data=df)
    plt.title('USD to IDR Exchange Rate Over Time')
    plt.xlabel('Date')
    plt.ylabel('Exchange Rate (IDR)')
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # Save plot to a bytes object
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    
    return send_file(img, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)
